import { Table, InputNumber } from 'antd';
import React, { useState, useEffect } from 'react';

const TableDemo = () => {
  const [data, setData] = useState([]);
  const columns = [
    { title: 'Area', dataIndex: 'code', key: 'code' },
    { title: '2023', dataIndex: '2023', key: '2023' },
    { title: '2024', dataIndex: '2024', key: '2024' },
    { title: '2025', dataIndex: '2025', key: '2025' },
    { title: '2026', dataIndex: '2026', key: '2026' },
    { title: '2027', dataIndex: '2027', key: '2027' }
  ];
  const [test, setTest] = useState();
  const [arr, setArr] = useState([]);
  const [dataSource, setDataSource] = useState([]);
  const handleValueChange = (value) => {
    console.log(test)
    console.log(data);
    console.log(dataSource);
  }

  const initData = () => {
    setData([
      { code: 'china', year: '2023', quota: 30 },
      { code: 'america', year: '2023', quota: 60 },
      { code: 'japan', year: '2023' },
      { code: 'canada', year: '2023' },
      { code: 'TTL', year: '2023', quota: 90 },
      { code: 'china', year: '2024' },
      { code: 'america', year: '2024' },
      { code: 'japan', year: '2024' },
      { code: 'canada', year: '2024' },
      { code: 'TTL', year: '2024' },
      { code: 'china', year: '2025' },
      { code: 'america', year: '2025' },
      { code: 'japan', year: '2025' },
      { code: 'canada', year: '2025' },
      { code: 'TTL', year: '2025' },
      { code: 'china', year: '2026' },
      { code: 'america', year: '2026' },
      { code: 'japan', year: '2026' },
      { code: 'canada', year: '2026' },
      { code: 'TTL', year: '2026' },
      { code: 'china', year: '2027' },
      { code: 'america', year: '2027' },
      { code: 'japan', year: '2027' },
      { code: 'canada', year: '2027' },
      { code: 'TTL', year: '2027' }
    ])
  }
  const initDataSource = () => {
    const dataTable = {};
    data.forEach(row => {
      if (!dataTable[row.code]) {
        dataTable[row.code] = { code: row.code };
      }
      dataTable[row.code][row.year] = row.quota || <InputNumber onChange={(value) =>
        handleValueChange(value)
      } />;
    });

    const dataSource1 = Object.values(dataTable);
    console.log(dataSource1)
    setDataSource([...dataSource1])
  }

  useEffect(() => {
    setTest("aaa")
    initData();
  }, [])

  useEffect(() => {
    initDataSource()
  }, [data])
  return (
    <>
    <Table
      dataSource={dataSource}
      columns={columns}
      pagination={false}
      bordered
    />
    </>
  );
};

export default TableDemo;
