import React, { useState, useEffect } from 'react';
import { Table, InputNumber } from 'antd';

const QuotaTable = () => {

  const dataSource = [
    { code: 'china', '2023': 30, '2024': 0, '2025': 0, '2026': 0, '2027': 0 },
    { code: 'america', '2023': 30, '2024': 0, '2025': 0, '2026': 0, '2027': 0 },
    { code: 'japan', '2023': 30, '2024': 0, '2025': 0, '2026': 0, '2027': 0 },
    { code: 'canada', '2023': 30, '2024': 0, '2025': 0, '2026': 0, '2027': 0 },
    { code: 'TTL', '2023': 30, '2024': 0, '2025': 0, '2026': 0, '2027': 0 },
  ];

  const [data, setData] = useState([...dataSource]);
  const handleQuotaChange = (record, year, value) => {
    const updatedRecord = { ...record, [year]: value };
    const newData = data.map((d) => {
      if (d.code === 'TTL') {
        const totalQuota = data
          .filter((d) => d.code !== 'TTL')
          .reduce((acc, d) => acc + (d[year] || 0), 0);
        updatedRecord[year] = totalQuota;
      }
      return updatedRecord;
    });

    setData(newData);
  };
  useEffect(()=>{
    initData();
  },[])
  const columns = [
    {
      title: 'Area',
      dataIndex: 'code',
      key: 'code',
      width: '20%',
    },
    {
      title: '2023',
      dataIndex: '2023',
      key: '2023',
      width: '16.67%',
      render: (_, record) => (
        <InputNumber
          min={0}
          defaultValue={record['2023']}
          onChange={(value) => handleQuotaChange(record, '2023', value)}
        />
      ),
    },
    {
      title: '2024',
      dataIndex: '2024',
      key: '2024',
      width: '16.67%',
      render: (_, record) => (
        <InputNumber
          min={0}
          defaultValue={record['2024']}
          onChange={(value) => handleQuotaChange(record, '2024', value)}
        />
      ),
    },
    {
      title: '2025',
      dataIndex: '2025',
      key: '2025',
      width: '16.67%',
      render: (_, record) => (
        <InputNumber
          min={0}
          defaultValue={record['2025']}
          onChange={(value) => handleQuotaChange(record, '2025', value)}
        />
      ),
    },
    {
      title: '2026',
      dataIndex: '2026',
      key: '2026',
      width: '16.67%',
      render: (_, record) => (
        <InputNumber
          min={0}
          defaultValue={record['2026']}
          onChange={(value) => handleQuotaChange(record, '2026', value)}
        />
      ),
    },
    {
      title: '2027',
      dataIndex: '2027',
      key: '2027',
      width: '16.67%',
      render: (_, record) => (
        <InputNumber
          min={0}
          defaultValue={record['2027']}
          onChange={(value) => handleQuotaChange(record, '2027', value)}
        />
      ),
    },
  ];

  const initData = ()=>{
    let arr = [];
    for (let i = 0; i < 5; i++) {
    var tmpArray = [{ code: 'china', year:'202'+(3+i)},
    { code: 'america', year:'202'+(3+i)},
    { code: 'japan', year:'202'+(3+i)},
    { code: 'canada', year:'202'+(3+i)},{ code: 'TTL', year:'202'+(3+i)},]
    arr = arr.concat(tmpArray)
  } 
  console.log(JSON.stringify(arr))
};

return (
  <Table
    dataSource={data}
    columns={columns}
    pagination={false}
    bordered
    size="small"
  // components={{
  //   body: {
  //     cell: EditableCell,
  //   },
  // }}
  />
);
};

export default QuotaTable;
