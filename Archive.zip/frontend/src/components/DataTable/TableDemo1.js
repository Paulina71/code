import { Menu, Dropdown, Button } from 'antd';
import { DownOutlined, CheckOutlined } from '@ant-design/icons';

const menu = (
  <Menu selectedKeys={['1']}>
    <Menu.Item key="1" icon={<CheckOutlined />}>
      Option 1
    </Menu.Item>
    <Menu.Item key="2">Option 2</Menu.Item>
    <Menu.Item key="3">Option 3</Menu.Item>
  </Menu>
);

const style = {
  backgroundColor: 'grey',
};

const TableDemo1 = () => (
  <Dropdown overlay={menu} placement="bottomLeft">
    <Button>
      Dropdown <DownOutlined />
    </Button>
  </Dropdown>
);


export default TableDemo1;