import { ShoppingCartOutlined } from '@ant-design/icons';
import { Badge } from 'antd'


const ShoppingCartMenu = () => {
  return (
    <Badge count={3} className="cart-container">
      <ShoppingCartOutlined style={{ fontSize: '24px' }} />
    </Badge>
  );
};
export default ShoppingCartMenu;