import React, { useState } from 'react';
import './index.css';
import { SlackOutlined, } from '@ant-design/icons';
import { Menu, Dropdown } from 'antd';
import axios from '../../axiosInstance';
import { useNavigate } from 'react-router-dom';
import ShoppingCartMenu from './shoppingChart';

const CustomHeader = () => {
  const navigate = useNavigate();
  const [selectedKey, setSelectedKey] = useState('home');

  const handleLogout = async () => {
    // TODO: implement logout functionality
    try {
      const response = await axios.post('/api/logout');
      console.log(response);
      // Remove JWT token from localStorage
      if (response.status === 200) {
        localStorage.removeItem('token');
        localStorage.removeItem('email');
        // localStorage.removeItem('role')
        navigate('/login');
      }
    } catch (error) {
      console.error(error);
    }
  };

  function handleMenuClick(key1) {
    switch (key1) {
      case 'home':
        navigate('/home');
        break;
      case 'about-us':
        navigate('/aboutus');
        break;
      case 'free-courses':
        navigate('/all-courses');
        break;
      case 'enrollment':
        navigate('/enrollment');
        break;
      case 'my-courses':
          navigate('/courses');
          break;
      default:
        break;
    }
    setSelectedKey(key1);
  }

  const signInMenu = (
    <Menu>
      <Menu.Item key="programmer" onClick={() => {
        localStorage.setItem('role', 'programmer')
        navigate('/login/programmer')
      }}>
        Sign in as Programmer
      </Menu.Item>
      <Menu.Item key="learner" onClick={() => {
        localStorage.setItem('role', 'learner')
        navigate('/login/learner')
      }}>
        Sign in as Learner
      </Menu.Item>
    </Menu>
  );

  const logoutMenu = (
    <Menu>
      <Menu.Item key="logout" onClick={() => {
        // localStorage.setItem('role', 'programmer')
        handleLogout()
      }}>
        Log out
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="header-container">
      <div className="logo-container">
        <SlackOutlined className="logo" />
        <span className="title">Programmers</span>
      </div>
      <div className="menu-container">
        <Menu mode="horizontal" selectedKeys={[selectedKey]} style={{ minWidth: '500px' }}>
          <Menu.Item key="home" onClick={() => handleMenuClick('home')}>Home</Menu.Item>
          <Menu.Item key="about-us" onClick={() => handleMenuClick('about-us')}>About Us</Menu.Item>
          <Menu.Item key="free-courses" onClick={() => handleMenuClick('free-courses')}>All Courses</Menu.Item>
          {localStorage.getItem('role') === "learner" && <Menu.Item key="enrollment" onClick={() => handleMenuClick('enrollment')}>Enrollment</Menu.Item>}
          {localStorage.getItem('role') === "programmer" && <Menu.Item key="my-courses" onClick={() => handleMenuClick('my-courses')}>My Courses</Menu.Item>}
        </Menu>
        <div className="actions">
          {/* <ShoppingCartMenu /> */}
          {localStorage.getItem('token') ? (
            <div className="logged-in">
              <Dropdown overlay={logoutMenu} placement="bottomRight">
                <span className="logout">
                Logged in as {localStorage.getItem('email')}
                </span>
              </Dropdown>
            </div>
          ) : (
            <>
              <Dropdown overlay={signInMenu} placement="bottomRight">
                {/* <span className="login" onClick={() => navigate('/login')}> */}
                <span className="login">
                  Sign In
                </span>
              </Dropdown>
              {/* <span className="signup" onClick={() => navigate('/signup')}>
                Sign Up
              </span> */}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomHeader;
