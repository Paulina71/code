import { PlusOutlined } from '@ant-design/icons';
import {
  DatePicker,
  Form,
  Input,
  Radio,
  InputNumber,
} from 'antd';
import { useState } from 'react';
import moment from 'moment';
import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import UpdateCoursePage from '../UpdateCoursePage';
dayjs.extend(customParseFormat);

const dateFormat = 'YYYY-MM-DD';
const { TextArea } = Input;
const AddCourse = (props) => {
  const [componentDisabled, setComponentDisabled] = useState(true);
  const [pdfFile, setPdfFile] = useState(null);
  const [videoFile, setVideoFile] = useState(null);
  const [tags, setTags] = useState([]);

  const handlePdfFileChange = (event) => {
    setPdfFile(event.target.files[0]);
    updateValue(event.target.files[0], 'pdf')
  };

  const handleVideoFileChange = (event) => {
    setVideoFile(event.target.files[0]);
    updateValue(event.target.files[0], 'video');
  };

  const handleTagInputChange = (event) => {
    setTags(event.target.value.split(","));
    updateValue(event.target.value.split(","), 'tags');
  };

  const updateValue = (value, key) => {
    props.setFormData({ ...props.formData, [key]: value });
  }
  return (
    <>
      <Form
        labelCol={{
          span: 4,
        }}
        wrapperCol={{
          span: 14,
        }}
        layout="horizontal"
        style={{
          maxWidth: 600,
        }}
      >
        <Form.Item label="Name" required={true}>
          <Input value={props.formData.course_name}
            onChange={(event) => updateValue(event.target.value, 'title')} />
        </Form.Item>
        {/* <Form.Item label="Code" required={true}>
          <Input value={props.formData.course_code}
            onChange={(event) => updateValue(event.target.value, 'course_code')} />
        </Form.Item> */}
        <Form.Item label="Price" required={true}>
          {/* <Radio.Group
            value={props.formData.level}
            onChange={(event) => updateValue(event.target.value, 'level')}>
            <Radio value="Junior"> Junior </Radio>
            <Radio value="Middle"> Middle </Radio>
            <Radio value="Senior"> Senior </Radio>
          </Radio.Group> */}
          <InputNumber
            defaultValue={0}
            min={0}
            max={1000}
            formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
            parser={(value) => value.replace(/\$\s?|(,*)/g, '')}
            onChange={(value) => updateValue(value, 'price')}
          />
        </Form.Item>
        {/* <Form.Item label="Department"
          required={true}>
          <Input
            onChange={(event) => updateValue(event.target.value, 'department')}
            value={props.formData.department}
          />
        </Form.Item> */}
        {/* <Form.Item label="Instructor"
          required={true}>
          <Input
            value={props.formData.instructor}
            onChange={(event) => updateValue(event.target.value, 'instructor')} />
        </Form.Item> */}
        <Form.Item label="Description"
          required={true}>
          <TextArea
            value={props.formData.description}
            onChange={(event) => updateValue(event.target.value, 'description')} />
        </Form.Item>
        {/* <Form.Item label="Start Date"
          required={true}>
          <DatePicker
            defaultValue={dayjs(moment(props.formData.start_date ? props.formData.start_date : new Date()).format('YYYY-MM-DD'), dateFormat)}
            onChange={(date, dateString) => updateValue(dateString, 'start_date')} />
        </Form.Item>
        <Form.Item label="End Date"
          required={true}>
          <DatePicker
            defaultValue={dayjs(moment(props.formData.end_date ? props.formData.end_date : new Date()).format('YYYY-MM-DD'), dateFormat)}
            onChange={(date, dateString) => updateValue(dateString, 'end_date')} />
        </Form.Item> */}
        <Form.Item label="Update PDF">
          {/* <label htmlFor="pdf-file">Update PDF File:</label> */}
          <input type="file" id="pdf-file" onChange={handlePdfFileChange} />
        </Form.Item>
        <Form.Item label="Update Video">
          {/* <label htmlFor="video-file">Update Video File:</label> */}
          <input type="file" id="video-file" onChange={handleVideoFileChange} />
        </Form.Item>
        <Form.Item label="Tags">
          {/* <label htmlFor="tag-input">Tags:</label> */}
          <input type="text" id="tag-input" onChange={handleTagInputChange} />
        </Form.Item>
      </Form>
    </>
  );
};
export default AddCourse;