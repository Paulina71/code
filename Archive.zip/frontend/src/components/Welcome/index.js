import React from 'react';
import { Link } from 'react-router-dom';
import './index.less';
import { useNavigate } from 'react-router-dom';

const courses = [
    {
        id: 1,
        title: 'Introduction to React',
        description: 'Learn the basics of React and create your first app',
        price: 9.99,
        free: false,
        tags: ['react', 'javascript'],
        teacher: {
            id: 1,
            name: 'John Smith'
        }
    },
    {
        id: 2,
        title: 'JavaScript for Beginners',
        description: 'A comprehensive guide to JavaScript for people new to programming',
        price: 0,
        free: true,
        tags: ['javascript'],
        teacher: {
            id: 2,
            name: 'Jane Doe'
        }
    },
    // more courses
];

function Welcome() {
  const navigate = useNavigate();

    return (
        <div className="welcome-page">
        <div className="welcome-page-header">
          <h1>Our Website</h1>
          <h2>Provides Professional Tutorial Videos</h2>
          <h2>For Beginners To Learn How To Code</h2>
          <button onClick={()=>navigate('/all-courses')}>Get Started</button>
        </div>
        <div className="welcome-page-features">
          <div className="feature">
            <h3>Learn From Experts</h3>
            <p>Our videos are created by industry experts with years of experience.</p>
          </div>
          <div className="feature">
            <h3>Flexible Learning</h3>
            <p>Learn at your own pace and on your own schedule.</p>
          </div>
          <div className="feature">
            <h3>High-Quality Content</h3>
            <p>Our videos are of the highest quality, ensuring a great learning experience.</p>
          </div>
        </div>
      </div>
    );
}

export default Welcome;
