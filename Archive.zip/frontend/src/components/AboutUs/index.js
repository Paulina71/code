import React from "react";
import "./index.less";
import { Row, Col, Typography, Card } from "antd";

const { Title, Text, Paragraph } = Typography;

const AboutPage = () => {
return (
<div className="about-page-container">
<Row>
<Col span={24}>
<Title level={2}>Our Team</Title>
<Text>
Welcome to our online learning platform, where learners and programmers can come together to share knowledge and grow their skills.
Our platform provides a space for programmers to upload and download videos or PDF files, write descriptions, and add tags. Programmers also have the same rights as learners to add comments, favorite videos/PDFs, share videos/PDFs, and search for courses.
Our main goal is to provide high-quality coding tutorials and courses for learners. As a learner, you can watch different coding videos on the platform, learn some coding skills, and even purchase professional coding courses.
If you are confused about the two modes, programmer or learner, you can learn more about them on this page. As a programmer, you can sell your tutorial videos to learners on the platform and gain more followers.
</Text>
</Col>
</Row>
<Row>
<Col span={24}>
<Title level={2}>Modes</Title>
</Col>
</Row>
<Row span={24} justify="center">
<Col span={12}>
<Title level={3}>Learner Mode</Title>
<Card className="card-container">
<Title level={4}>Upload and Share</Title>
<Paragraph>
As a programmer, you can upload and share your coding tutorials in the form of videos or PDF files. You can also add a description and tags to help learners find your tutorials easily.
</Paragraph>
<Title level={4}>Comments and Favorites</Title>
<Paragraph>
You can also add comments to the tutorials, and other learners can add them too. You can also add the tutorial to your favorites for later viewing.
</Paragraph>
<Title level={4}>Sell Your Videos and PDFs</Title>
<Paragraph>
If you have professional coding courses, you can also sell them on the platform and earn money.
</Paragraph>
</Card>
</Col>
<Col span={12}>
<Title level={3}>Programmer Mode</Title>
<Card className="card-container">
<Title level={4}>Upload and Share</Title>
<Paragraph>
As a programmer, you can upload and share your coding tutorials in the form of videos or PDF files. You can also add a description and tags to help learners find your tutorials easily.
</Paragraph>
<Title level={4}>Comments and Favorites</Title>
<Paragraph>
You can also add comments to the tutorials, and other learners can add them too. You can also add the tutorial to your favorites for later viewing.
</Paragraph>
<Title level={4}>Sell Your Videos and PDFs</Title>
<Paragraph>
If you have professional coding courses, you can also sell them on the platform and earn money.
</Paragraph>
</Card>
</Col>
</Row>
</div>
);
};

export default AboutPage;