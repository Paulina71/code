import React, { useState, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';

// 设置 PDF.js 的 worker 路径
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

const PdfViewer = ({ pdfUrl }) => {
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);

  // 在组件挂载时，获取 PDF 文件总页数
  useEffect(() => {
    const fetchNumPages = async () => {
      const pdfDoc = await pdfjs.getDocument(pdfUrl).promise;
      setNumPages(pdfDoc.numPages);
    };
    fetchNumPages();
  }, [pdfUrl]);

  const onDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
  };

  const handlePageChange = (newPageNumber) => {
    setPageNumber(newPageNumber);
  };

  return (
    <div>
      <Document file={pdfUrl} onLoadSuccess={onDocumentLoadSuccess}>
        <Page pageNumber={pageNumber} />
      </Document>
      <div>
        <button disabled={pageNumber <= 1} onClick={() => handlePageChange(pageNumber - 1)}>
          Previous
        </button>
        <span>
          Page {pageNumber} of {numPages}
        </span>
        <button disabled={pageNumber >= numPages} onClick={() => handlePageChange(pageNumber + 1)}>
          Next
        </button>
      </div>
    </div>
  );
};

export default PdfViewer;
