import React, { useState } from "react";

const UpdateCoursePage = () => {
  const [pdfFile, setPdfFile] = useState(null);
  const [videoFile, setVideoFile] = useState(null);
  const [tags, setTags] = useState([]);

  const handlePdfFileChange = (event) => {
    setPdfFile(event.target.files[0]);
  };

  const handleVideoFileChange = (event) => {
    setVideoFile(event.target.files[0]);
  };

  const handleTagInputChange = (event) => {
    setTags(event.target.value.split(","));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // TODO: Handle form submission with updated PDF and video files and tags
  };

  return (
    <div>
      <h1>Update Course</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="pdf-file">Update PDF File:</label>
          <input type="file" id="pdf-file" onChange={handlePdfFileChange} />
        </div>
        <div>
          <label htmlFor="video-file">Update Video File:</label>
          <input type="file" id="video-file" onChange={handleVideoFileChange} />
        </div>
        <div>
          <label htmlFor="tag-input">Tags:</label>
          <input type="text" id="tag-input" onChange={handleTagInputChange} />
        </div>
      </form>
    </div>
  );
};

export default UpdateCoursePage;
