import { Button, Card } from 'antd';
import { useEffect, useState } from 'react';
import ReactPlayer from 'react-player';
import { useLocation } from 'react-router-dom';
import axios from '../../axiosInstance';

const CourseDetailPage = () => {
  const location = useLocation();
  const [videoUrl, setVideoUrl] = useState('');
  const [course, setCourse] = useState({...location.state.course, pdf:'',video:""});
  //get video and pdf
  useEffect(() => {
    axios.get('/videos/' + course.id)
      .then(response => {
        let course1 = course;
        course1.video = response.data[0].file
        setCourse({ ...course1});
        console.log(response.data[0].file)
        setTimeout(()=>{
          console.log(course)
        },1000)
       
        axios.get('/video/' + response.data[0].file, {
          responseType: 'blob' // 设置响应类型为二进制流
        })
          .then(response1 => {
            const url = window.URL.createObjectURL(new Blob([response1.data]));
            const video = document.createElement('video');
            video.src = url;
            setCourse({ ...course, videoUrl: url });
            // 将 video 元素添加到页面中
          })
          .catch(error1 => {
            // Handle the error
          });
      })
      .catch(error => {
        // Handle the error
      });
    axios.get('/pdfs/' + course.id)
      .then(response => {
        let course1 = course;
        course1.pdf = response.data[0].file
        setCourse({ ...course1});
        axios.get('/video/' + response.data[0].file, {
          responseType: 'blob' // 设置响应类型为二进制流
        })
          .then(response1 => {
            const url = window.URL.createObjectURL(new Blob([response1.data]));
            const video = document.createElement('video');
            video.src = url;
            setCourse({ ...course, pdfUrl: url });
            // 将 video 元素添加到页面中
          })
          .catch(error1 => {
            // Handle the error
          });

      })
      .catch(error => {
        // Handle the error
      });

  }, [])
  const handleDownload = async (file) => {
    try {
      const response = await axios.get('/video/' + file, {
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', file);
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.log(error);
    }
  };
  // const course = {
  //   id: 1,
  //   name: 'Introduction to Programming',
  //   description: 'This course will teach you the basics of programming using Python.',
  //   videoUrl: 'https://example.com/course1.mp4',
  //   pdfUrl: 'https://example.com/course1.pdf',
  // };

  return (
    <div>
      <h1>{course.name}</h1>
      {videoUrl && (
        <video width="320" height="240" controls>
          <source src={videoUrl} type="video/mp4" />
        </video>
      )}
      <Card>
        <ReactPlayer url={course.videoUrl} controls width="100%" />
      </Card>
      <div style={{ marginTop: 16 }}>
        <Button type="primary" onClick={()=>handleDownload(course.video)} download>
          Download Video {course.video}
        </Button>{' '}
        <Button type="primary" onClick={()=>handleDownload(course.pdf)} download>
          Download PDF {course.pdf}
        </Button>
      </div>
    </div>
  );
};

export default CourseDetailPage;
