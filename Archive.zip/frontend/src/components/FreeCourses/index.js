import { Card, List, Button } from 'antd';
import { useEffect, useState } from 'react';
import courses1 from '../../assets/images/course1.jpg';
import courses2 from '../../assets/images/course2.jpg';
import courses3 from '../../assets/images/course3.jpg';
import axios from '../../axiosInstance';
import { HeartOutlined, HeartFilled, ShareAltOutlined, ShoppingCartOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';

const courses = [
  {
    id: 1,
    name: 'Introduction to Programming',
    description: 'This course will teach you the basics of programming using Python.',
    image: courses1,
  },
  {
    id: 2,
    name: 'Web Development Fundamentals',
    description: 'Learn the fundamentals of web development with HTML, CSS, and JavaScript.',
    image: courses2,
  },
  {
    id: 3,
    name: 'Data Science with R',
    description: 'Explore data science concepts and learn how to use R to analyze data.',
    image: courses3,
  },
];



const FreeCoursesPage = () => {
  const [allcourses, setCourses] = useState();
  const [favorites, setFavorites] = useState([]);
  const [shared, setShared] = useState(false);

  const navigate = useNavigate();

  const handleShare = (course) => {
    // Handle the share action here
    setShared(true);
    console.log(`Course "${course.title}" shared`);
  };

  const toggleFavorite = (course) => {
    if (favorites.includes(course.id)) {
      setFavorites(favorites.filter((id) => id !== course.id));
    } else {
      setFavorites([...favorites, course.id]);
    }
  };

  useEffect(() => {
    axios.get('/allcourses')
      .then(response => {
        setCourses([...response.data])
      })
      .catch(error => {
        // Handle the error
      });
  }, [])

  return (
    <div>
      <h1>Free Courses</h1>
      <List
        grid={{ gutter: 16, column: 4 }}
        dataSource={courses}
        renderItem={(course) => (
          <List.Item>
            <Card
              hoverable
              style={{ width: '90%' }}
              cover={<img alt={course.name} src={course.image} style={{ height: '212px' }} />}
            // actions={[
            //   <Button
            //     icon={favorites.includes(course.id) ? <HeartFilled style={{ color: '#4096ff' }} /> : <HeartOutlined />}
            //     onClick={() => toggleFavorite(course)}
            //   />,
            // ]}
            >
              <Card.Meta title={course.name} description={course.description} />
            </Card>
          </List.Item>
        )}
      />
      <h1>Fee Courses</h1>
      <List
        grid={{ gutter: 16, column: 4 }}
        dataSource={allcourses}
        locale={{ emptyText: "No data. Please Login." }}
        renderItem={(course) => (
          <List.Item>
            <Card
              hoverable
              style={{ width: '90%' }}
              cover={<img alt={course.title} src={course.image} style={{ height: '212px' }} />}
              onClick={()=>navigate("/courseDetail/"+course.id, { state: { course } })}
              actions={[
                <Button
                  icon={favorites.includes(course.id) ? <HeartFilled style={{ color: '#4096ff' }} /> : <HeartOutlined />}
                  onClick={() => toggleFavorite(course)}
                />,
                <Button icon={<ShareAltOutlined />} onClick={() => handleShare(course)} />,
                <Button icon={<ShoppingCartOutlined />} onClick={() => { }} />,
              ]}
            >
              <Card.Meta title={course.title} description={course.description} />
              <div style={{ fontWeight: 'bold', marginTop: '12px' }}>
                Price: {course.price} USD
              </div>
            </Card>
          </List.Item>
        )}
      />
    </div>
  );
};

export default FreeCoursesPage;
