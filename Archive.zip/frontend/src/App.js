import './App.css';
import CustomHeader from './components/CustomHeader';
// import SideBar from './components/SideBar/SideBar';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import Register from './components/Register';
import Welcome from './components/Welcome';
import AboutUsPage from './components/AboutUs';
import Courses from './components/Courses';
import FreeCoursesPage from './components/FreeCourses';
import CourseDetailPage from './components/CourseDetail';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/home" />} />
        <Route path="/login/*" element={
          <>
            <CustomHeader />
            <LoginPage />
          </>
        } />
        <Route path="/signup" element={
          <>
            <CustomHeader />
            <Register />
          </>
        } />
        {/* <Route path="/dashboard" element={
          <>
            <CustomHeader />
            <div className="App">
              <SideBar />
            </div>
          </>
        } /> */}
        <Route path="/all-courses" element={
          <>
            <CustomHeader />
            <div className="App">
              <FreeCoursesPage />
            </div>
          </>
        } />
        <Route path="/courses" element={
          <>
            <CustomHeader />
            <div className="App">
              <Courses />
            </div>
          </>
        } />
        <Route path="/home" element={
          <>
            <CustomHeader />
            <Welcome />
          </>
        } />
        <Route path="/courseDetail/:courseId" element={
          <>
            <CustomHeader />
            <CourseDetailPage />
          </>
        } />
        <Route path="/aboutus" element={
          <>
            <CustomHeader />
            <AboutUsPage />
          </>
        } />
      </Routes>
    </Router>
  );
}

export default App;
